# Pampuna website preview

Serve this folder with python3 -m http.server 8000 and open index.html.
Main.dc.html contains the same design component. Retains the supplied export runtime.

Portfolio: PrimeCut and Victory Car Rental, using the supplied screenshots.
PrimeCut links to getprimecut.com. Add Victory Car Rental’s confirmed URL when available.
The editing FAQ confirms customers can edit their site and contact Pampuna anytime for changes.

Before publishing: connect a real form destination and add actual contact details.
The request form currently downloads a text request locally and sends nothing.
Confirm commercial scope and recurring costs. Perform desktop and mobile visual review;
browser verification is still outstanding. The layout uses content-led heights,
compact spacing, tablet/laptop columns, and stacked phone layouts.

Branding and social media management are now presented together as a selectable
package, with brand setup and monthly management. Platforms, post count, and
comment/message handling are agreed in scope. No photography or video offer
is advertised. Hero, inquiry choices, and footer also reflect the service.

## Review fixes (browser-checked at 375, 390, 768, 1024, 1200, 1366, 1440 px)

- Menu order now matches the page: Possibilities, then Services & packages.
- Phones and tablets (up to 1023px): logo and "Let's talk" share the first header row,
  section links sit on the second; the duplicate "Your business" link is hidden there.
  Header height on a phone dropped from 162px to 106px.
- Closing call-to-action: up to 1199px the pumpkin is a small corner badge with space
  above the headline, so it no longer covers the text.
- Phone hero: the decorative leaf that overlapped the headline is hidden, and the hero
  buttons use slightly tighter type so "Explore the possibilities" stays on one line.
- Request form: "Your name" and "Email or WhatsApp" labels match the other labels and
  are marked Required. On tablets the two field columns can shrink, so fields no longer
  spill past the card edge.
- Section spacing increased: clamp(64px, 9vh, 104px) top and bottom on desktop, 56px on
  short laptop screens and on phones (was 24-48px, which made sections feel cramped).
- Scrolling banner made smaller: 20px text, 16px leaf icons, 12px padding (about 51px
  tall instead of 84px).
- "Branding & social media" removed from the add-ons list, since it is already a main
  goal (picking both listed it inside its own package).

## Contact and request form (live)

- "Send my request" emails the request to pampunacreatives@gmail.com through FormSubmit
  (formsubmit.co, free, no server needed). The visitor's email is set as reply-to.
- ONE-TIME ACTIVATION: the very first request sent from the live site makes FormSubmit
  email pampunacreatives@gmail.com an "Activate Form" link. Click it once; until then,
  requests are not delivered. Send yourself a test request after publishing.
- "Or send on WhatsApp" opens a WhatsApp chat with +599 9 678 0222 with the request
  already typed in; the visitor taps send.
- If sending fails, the form shows a message pointing to WhatsApp and the email address.
- Email, WhatsApp number and Instagram (@pampuna.cw) are shown in the closing section
  and the footer.
- "What would you like help with?" is labelled Optional.

- Pampuna "P." logo (assets/pampuna-logo.png, transparent) replaces the pumpkin icon in the
  header; assets/favicon.png is the browser-tab icon. Slightly smaller on phones so the
  header stays on two rows.
- Phones: in Services & packages, the main-goal and add-on choices are each one row
  that swipes sideways, instead of stacking down the page.

## Pre-launch updates

- Portfolio screenshots compressed to JPEG (1400px wide): about 240 KB in total instead
  of 3.8 MB, so section 01 loads quickly on phones.
- Victory Car Rental now links to https://victorycarrental.com ("Visit website").
- Search description updated to cover websites, branding and social media management.
- Link-preview tags added (og:title, og:description, og:image and a Twitter/X card) with
  assets/og-image.jpg (1200x630), so shared links show the Pampuna logo and tagline.
- No prices are shown anywhere on the page.

## Publishing on GitHub Pages

1. Create a new public repository on github.com (for example "pampuna-website").
2. Upload everything inside this Pampuna-Home folder (index.html must be at the top
   level of the repository, next to the assets and vendor folders).
3. Repository Settings > Pages > Source: "Deploy from a branch", Branch: main, folder:
   / (root). Save. After a minute the site is live at
   https://YOUR-USERNAME.github.io/REPOSITORY-NAME/
4. Link previews: WhatsApp and Facebook need the full address of the preview image.
   Once you know the live address, change the og:image line in index.html to the full
   URL, e.g. https://YOUR-USERNAME.github.io/REPOSITORY-NAME/assets/og-image.jpg
5. Activate the email form: send yourself a test request from the live site, then click
   the "Activate Form" link FormSubmit emails to pampunacreatives@gmail.com.
6. Optional: to use your own domain (for example pampuna.cw), add it under
   Settings > Pages > Custom domain and follow GitHub's DNS instructions.

## Building since 2023 (newspaper feature)

- Between the scrolling banner and section 01 (Possibilities) there is now a "Building since 2023"
  section (#since-2023) with a card with the Extra newspaper clipping (4 March 2023, p. 27) about the graduation project
  (profielwerkstuk) presentations at Maria Immaculata Lyceum. Clicking the photo opens it full size.
- assets/extra-newspaper-2023.jpg is cropped to the headline, photos and start of the article;
  the death notices printed lower on the same page are deliberately left out.

## Colour palette: no yellow

- All yellow (#FFC23D, #FFD25A, amber accent option) is removed. The page now uses orange (#FF6A13),
  green (#2FB36B), purple (#5B2A86), white/cream (#FFF8EF) and the dark ink (#1E1230).
- Leaves are green, the closing-section pumpkin and "Building since 2023" badge are orange,
  the Launch step card is orange, and "Lights on" mode glows orange.
